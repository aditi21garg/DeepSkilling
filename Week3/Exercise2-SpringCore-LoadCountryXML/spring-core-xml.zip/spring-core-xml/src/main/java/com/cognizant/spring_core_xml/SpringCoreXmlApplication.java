package com.cognizant.spring_core_xml;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringCoreXmlApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringCoreXmlApplication.class, args);
	}

}
